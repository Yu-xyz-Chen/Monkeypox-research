# 这是一个示例 Python 脚本。

# 按 Shift+F10 执行或将其替换为您的代码。
# 按 双击 Shift 在所有地方搜索类、文件、工具窗口、操作和设置。

import libpysal
import numpy as np
import giddy
import pandas

f = pandas.read_csv("D://毕业设计//Data//马尔科夫链//107-37week-morbidity.csv",header='infer',usecols=[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37])
Data = np.array(f)
data1=Data[:,1:38]
data=data1.T


import matplotlib.pyplot as plt

weeks = range(20,57)
names = np.array(f["country"])
order0 = np.argsort(data[0,:])
order56 = np.argsort(data[-1,:])
names0 = names[order0[::-1]]
names56 = names[order56[::-1]]
first_last = np.vstack((names0,names56))
from pylab import rcParams
rcParams['figure.figsize'] = 25,10
plt.plot(weeks,data)
for i in range(107):
    plt.text(-6.5,17.81-(i*0.167), first_last[0][i],fontsize=7)
    plt.text(56.5,17.81-(i*0.167), first_last[1][i],fontsize=7)
plt.xlim((weeks[0], weeks[-1]))
plt.ylim((0, 17.81))
plt.ylabel('发病率/10万人',fontproperties = "SimSun",fontsize=14)
plt.xlabel('Weeks',fontsize=12)
plt.title('Absolute Dynamics',fontsize=18)
plt.show()

weeks = range(20,57)
rdata= (data.T / data.mean(axis=1)).T
names = np.array(f["country"])
rorder0 = np.argsort(rdata[0,:])
rorder56 = np.argsort(rdata[-1,:])
rnames0 = names[rorder0[::-1]]
rnames56 = names[rorder56[::-1]]
rfirst_last = np.vstack((rnames0,rnames56))
from pylab import rcParams
rcParams['figure.figsize'] = 25,10
plt.plot(weeks,rdata)
for i in range(107):
    plt.text(-6.5, 107 - (i * 1), first_last[0][i], fontsize=7)
    plt.text(56.5, 107 - (i * 1), first_last[1][i], fontsize=7)
plt.xlim((weeks[0], weeks[-1]))
plt.ylim((0, 107))
plt.ylabel('发病率相对值',fontproperties="SimSun",fontsize=14)
plt.xlabel('Weeks',fontsize=12)
plt.title('Relative Dynamics',fontsize=18)
# plt.show()

import mapclassify as mc
q5 = np.array([mc.Quantiles(y,k=5).yb for y in data]).transpose()
print(q5[:, 0])
print(q5[:, 0])
print(f["country"])
print(q5[4, :])
m5 = giddy.markov.Markov(q5)
print(m5.transitions)
print(m5.p)
print(m5.steady_state)
print(giddy.ergodic.fmpt(m5.p))


import geopandas as gpd
import pandas as pd
geo_table = gpd.read_file("C://Users//86183//Desktop//毕业论文//数据//全球猴痘数据//shp//Only107countries.shp")
income_table = pd.read_csv("D://毕业设计//Data//马尔科夫链//107-37week-morbidity.csv",header='infer',usecols=[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40])
complete_table = geo_table.merge(income_table,left_on='iso3',right_on='iso')
complete_table.head()

# index_week = range(0,57,10)
# fig, axes = plt.subplots(nrows=2, ncols=3,figsize = (15,7))
# for i in range(2):
#     for j in range(3):
#         ax = axes[i,j]
#         complete_table.plot(ax=ax, column=str(index_week[i*3+j]), cmap='OrRd', scheme='quantiles', legend=True)
#         ax.set_title('Per Capita Morbidity %s Quintiles'%str(index_week[i*3+j]))
#         ax.axis('off')
#         leg = ax.get_legend()
#         leg.set_bbox_to_anchor((0.8, 0.15, 0.16, 0.2))
# plt.tight_layout()
# plt.show()
from esda.moran import Moran
import matplotlib.pyplot as plt
#
from libpysal.weights import W
w = libpysal.io.open("C://Users//86183//Desktop//毕业论文//数据//全球猴痘数据//shp//ID_Only107countries.gal").read()
w.transform = 'R'
# mits = [Moran(cs, w) for cs in pci]
# res = np.array([(mi.I, mi.EI, mi.seI_norm, mi.sim[974]) for mi in mits])
# years = np.arange(1929,2010)
# fig, ax = plt.subplots(nrows=1, ncols=1,figsize = (10,5) )
# ax.plot(years, res[:,0], label='Moran\'s I')
# #plot(years, res[:,1], label='E[I]')
# ax.plot(years, res[:,1]+1.96*res[:,2], label='Upper bound',linestyle='dashed')
# ax.plot(years, res[:,1]-1.96*res[:,2], label='Lower bound',linestyle='dashed')
# ax.set_title("Global spatial autocorrelation for annual US per capita incomes",fontdict={'fontsize':15})
# ax.set_xlim([1929,2009])
# ax.legend()
rdata1 = rdata.astype(np.float32)
sm = giddy.markov.Spatial_Markov(rdata1.T, w, fixed = True, k = 5,m=5)
print(sm.p)
# sm.summary()
print(sm.F)
Result=open("D://毕业设计//result//空间马尔可夫分析//新增发病率-37week//Time.txt",mode='w')
import numpy as np
np.savetxt(Result, (sm.F).reshape(-1,1),fmt = '%f',delimiter = ',')
Result.flush() # 一定要加这个！！！否则貌似会漏数据，，还是有这个习惯好

import seaborn as sns
sns.set()
fig, ax = plt.subplots(figsize = (5,4))
im = sns.heatmap(sm.p, annot=True, linewidths=.5, ax=ax, cbar=True, vmin=0, vmax=1,
                          square=True,  cmap="YlGn",fmt='.3f')
fig, axes = plt.subplots(2,2,figsize = (15,8))

for i in range(2):
    for j in range(2):
        ax = axes[i,j]
        if i==1 and j==2:
            ax.axis('off')
            continue
        p_temp = sm.P[i*2+j]
        im = sns.heatmap(p_temp, annot=True, linewidths=.5, ax=ax, cbar=True, vmin=0, vmax=1,
                          square=True, cmap="YlGn",fmt='.3f')
        ax.set_title("Spatial Lag %d"%(i*2+j),fontsize=13)

fig, axes = plt.subplots(2,3,figsize = (15,8))

for i in range(2):
    for j in range(3):
        ax = axes[i,j]
        if i==0 and j==0:
            im = sns.heatmap(sm.p, annot=True, linewidths=.5, ax=ax, cbar=True, vmin=0, vmax=1,
                          square=True, cmap="YlGn",fmt='.3f')
            ax.set_title("Global",fontsize=13)
        elif i==1 and j==2:
            ax.axis('off')
        else:
            p_temp = sm.P[i*3+j-1]
            im = sns.heatmap(p_temp, annot=True, linewidths=.5, ax=ax, cbar=True, vmin=0, vmax=1,
                          square=True, cmap="YlGn",fmt='.3f')
            ax.set_title("Spatial Lag %d"%(i*2+j),fontsize=13)

