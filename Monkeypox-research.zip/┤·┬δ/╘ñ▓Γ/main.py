import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import MinMaxScaler
from torch_geometric_temporal.nn.recurrent import DCRNN
from torch_geometric_temporal import StaticGraphTemporalSignal, GCLSTM, __all__
from tqdm import tqdm

TRAINING_LENGTH = 72
# 载入节点信息并进行预处理
node_cpu0 = pd.read_csv(r'D://毕业设计//code//Forecasting//STGCN_IJCAI-18-master//STGCN_IJCAI-18-master//dataset//newPeMSD7_V_107.csv', header=None)  # (10, 1008)
Weight=pd.read_csv(r'D://毕业设计//code//Forecasting//STGCN_IJCAI-18-master//STGCN_IJCAI-18-master//dataset//PeMSD7_W_30.csv',header=None)
# print(node_cpu0.shape)
# node_cpu0 = node_cpu0.transpose()  # (1008, 10)
# print(node_cpu0.shape)
node_cpu = np.zeros(node_cpu0.shape, dtype=float)
for j in range(node_cpu0.shape[1]):
    for i in range(len(node_cpu0)):
        if i == 0:
            node_cpu[i, j] = node_cpu0.iloc[i, j]
        elif i == len(node_cpu0):
            node_cpu[i, j] = node_cpu0.iloc[i, j]
        else:
            node_cpu[i, j] = np.mean(node_cpu0.iloc[i - 1:i + 2, j])

# print(node_cpu0)
print(node_cpu)
# print(node_cpu.shape)

def clean_train_test_data(traindata, testdata):
    sc = MinMaxScaler(feature_range=(0, 1))
    # sc = StandardScaler()
    train_data = sc.fit_transform(traindata)
    test_data = sc.transform(testdata)  # 利用训练集的属性对测试集进行归一化
    return train_data, test_data


# 将数据划分为训练集与测试集,前80%的数据作为训练集，后20%的数据作为测试集
train_size = int(len(node_cpu) * 0.8)
# print(len(node_cpu))
test_size = len(node_cpu) - train_size
train_data = node_cpu[0:train_size, :]
test_data = node_cpu[train_size:len(node_cpu), :]
train_data, test_data = clean_train_test_data(train_data, test_data)
# print(train_data.shape)(806, 10)
# print(test_data.shape)(202, 10)
train_data = np.array(train_data).transpose()
test_data = np.array(test_data).transpose()

# print(train_data.shape)#(10, 806)

def split_dataset(data, n_sequence, n_pre):
    '''
    对数据进行处理，根据输入模型的历史数据长度和预测数据长度对数据进行切分
    :param data: 输入数据集
    :param n_sequence: 历史数据长度
    :param n_pre: 预测数据长度
    :return: 划分好的train data和target data
    '''
    train_X, train_Y = [], []
    for i in range(data.shape[1] - n_sequence - n_pre):
        a = data[:, i:(i + n_sequence)]
        train_X.append(a)
        b = data[:, (i + n_sequence):(i + n_sequence + n_pre)]
        train_Y.append(b)

    train_X = np.array(train_X)
    train_Y = np.array(train_Y)

    return train_X, train_Y


history_data = 7
predict_data = 1
train_feature, train_target = split_dataset(train_data, history_data, predict_data)
test_feature, test_target = split_dataset(test_data, history_data, predict_data)
# print(train_feature.shape, train_target.shape)#(733, 10, 72) (733, 10, 1)
# print(test_feature.shape, test_target.shape)#(129, 10, 72) (129, 10, 1)

# 数据的邻接矩阵A
# edge_index = np.array(
#     [[0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, 7, 1, 2, 1, 6, 2, 3, 2, 8, 2, 9, 3, 4, 3, 5, 3, 6, 3, 7, 5, 9, 7, 8],
#      [1, 0, 2, 0, 3, 0, 4, 0, 5, 0, 7, 0, 2, 1, 6, 1, 3, 2, 8, 2, 9, 2, 4, 3, 5, 3, 6, 3, 7, 3, 9, 5, 8, 7]])
# # print(type(edge_index))
# edge_weight=np.ones(edge_index.shape[1])
# print(edge_weight)
'''PyG Temporal中的类似DataLoader的数据处理器：
    edge_index：是邻接矩阵；
    edge_weight：是每个链路的权重；
    features：是输入历史节点特征矩阵；
    targets：是输入预测节点特征举证ground-truth；'''
# import scipy.sparse as sp
Matrix = np.array(Weight)
# edge_index_temp = sp.coo_matrix(Matrix)
# print(type(edge_index_temp))
# values = edge_index_temp.data  # 边上对应权重值weight
# indices = np.vstack((edge_index_temp.row, edge_index_temp.col))  # 我们真正需要的coo形式
# edge_index_A = torch.LongTensor(indices)  # 我们真正需要的coo形式
# print(edge_index_A)
# i = torch.LongTensor(indices)  # 转tensor
# v = torch.LongTensor(values)  # 转tensor
# edge_index = torch.strided(i, v, edge_index_temp.shape)
# edge_index=torch.FloatTensor(Matrix)
# print(edge_index)
import numpy as np
import networkx as nx
# build a graph
G = nx.Graph()
for i in range(len(Matrix)):
    for j in range(len(Matrix)):
        G.add_edge(i, j)

import torch
from torch_geometric.data import InMemoryDataset, Data
from torch_geometric.utils import dense_to_sparse
x = torch.eye(G.number_of_nodes(), dtype=torch.float)
adj = nx.to_scipy_sparse_array(G).tocoo()
row = torch.from_numpy(adj.row.astype(np.int64)).to(torch.long)
col = torch.from_numpy(adj.col.astype(np.int64)).to(torch.long)
edge_index = torch.stack([row, col], dim=0)
print(edge_index)
# data = Data(x=x, edge_index=edge_index)
W=list(np.array(Matrix).flatten())
print(W)
edge_weight=torch.FloatTensor(W)

# edge_index, edge_weight = dense_to_sparse(adj)
print(edge_weight)


# print(v)
# print(edge_weight)
# edge_weight=v
# print(edge_weight)

train_dataset = StaticGraphTemporalSignal(edge_index=edge_index, edge_weight=edge_weight,
                                          features=train_feature, targets=train_target)
test_dataset = StaticGraphTemporalSignal(edge_index=edge_index, edge_weight=edge_weight,
                                         features=test_feature, targets=test_target)
# print("Number of train buckets: ", len(set(train_dataset)))#733
# print("Number of test buckets: ", len(set(test_dataset)))#129


class GCN_LSTM(torch.nn.Module):
    def __init__(self, node_features, input_size, output_size):
        super(GCN_LSTM, self).__init__()
        self.recurrent = GCLSTM(node_features, input_size, output_size)
        self.MLP = torch.nn.Sequential(
            torch.nn.Linear(input_size, input_size // 2),
            torch.nn.ReLU(inplace=True),
            torch.nn.Linear(input_size // 2, input_size // 4),
            torch.nn.ReLU(inplace=True),
            torch.nn.Linear(input_size // 4, output_size))

    def forward(self, x, edge_index, edge_weight):
        x, _ = self.recurrent(x, edge_index, edge_weight)
        x = F.relu(x)
        x = F.dropout(x, training=self.training)
        x = self.MLP(x)
        return x


model = GCN_LSTM(node_features=7, input_size=36, output_size=1)
optimizer = torch.optim.Adam(model.parameters(), lr=0.01, weight_decay=1.5e-3)
loss_mse = torch.nn.MSELoss()
loss_mae = torch.nn.L1Loss()
# scaler = MinMaxScaler(feature_range=(0, 1))
cost_list = []
# cost_list1=[]
model.train()
'''time为train size'''
for epoch in tqdm(range(100)):
    cost = 0
    # cost1=0
    for time, snapshot in enumerate(train_dataset):
        y_hat = model(snapshot.x, snapshot.edge_index, snapshot.edge_attr)
        # y_hat1=torch.detach(y_hat).numpy()
        # # y_hat1=np.array(y_hat)#test
        # y_hat1=scaler.inverse_transform(y_hat1)#测试
        # y_hat1=torch.FloatTensor(y_hat1)
        # y_real=np.array(snapshot.y)
        # y_real=scaler.inverse_transform(y_real)
        # y_real=torch.FloatTensor(y_real)
        cost = cost + loss_mse(y_hat, snapshot.y)
        # cost1=cost1+loss_mae(y_hat, snapshot.y)
        # cost=cost+loss_mse(y_hat1,y_real)
    cost = cost / (time + 1)
    # cost1 = cost1 / (time + 1)
    cost_list.append(cost.item())
    # cost_list1.append(cost1.item())
    cost.backward()
    # cost1.backward()
    optimizer.step()
    optimizer.zero_grad()
cost = cost.item()
# cost1 = cost1.item()
print("training MSE: {:.4f}".format(cost))
# print("training MAE: {:.4f}".format(cost1))
plt.plot(cost_list)
plt.xlabel("Epoch")
plt.ylabel("MSE")
plt.title("average of Training cost for 10 nodes")
plt.show()
# plt.plot(cost_list1)
# plt.xlabel("Epoch")
# plt.ylabel("MAE")
# plt.title("average of Training cost for 107 nodes")
# plt.show()

model.eval()
cost = 0
cost1=0
cost2=0
test_loss_mse = torch.nn.MSELoss()
test_loss_mae = torch.nn.L1Loss()
test_real = []
test_pre = []
cha = []
for time, snapshot in enumerate(test_dataset):
    y_hat = model(snapshot.x, snapshot.edge_index, snapshot.edge_attr)
    test_pre.append(y_hat.detach().numpy())
    test_real.append(snapshot.y.detach().numpy())
    cost = cost + torch.mean((y_hat - snapshot.y) ** 2)
    # cost1=cost1+test_loss_mse(y_hat, snapshot.y)
    cost2 = cost2 + test_loss_mae(y_hat, snapshot.y)
    cha_node = y_hat - snapshot.y
    cha.append(cha_node.detach().numpy())
    # print('cost', cost)
    # print('cha', cha_node)
cost = cost / (time + 1)
cost = cost.item()
# cost1 = cost1 / (time + 1)
# cost1 = cost1.item()
cost2 = cost2 / (time + 1)
cost2 = cost2.item()
print("test MSE: {:.4f}".format(cost))
# print("test MSE: {:.4f}".format(cost1))
print("test MAE: {:.4f}".format(cost2))
test_real = np.array(test_real)
test_real = test_real.reshape([test_real.shape[0], test_real.shape[1]])
# print(test_real)
test_pre = np.array(test_pre)
test_pre = test_pre.reshape([test_pre.shape[0], test_pre.shape[1]])
# print(test_pre)

#TEST
# scaler = MinMaxScaler(feature_range=(0, 1))
# test_pre1=test_pre[:,103]
# test_real1=test_real[:,103]
# y_pre=scaler.inverse_transform(test_pre)#测试
# y_real=scaler.inverse_transform(test_real)
import math
from sklearn import metrics
from sklearn.metrics import mean_squared_error
# Top10=np.array([103,13,34,81,38,29])
test_real1=np.array(test_real)

# import pandas as pd
# # print(test_pre[:, 0])
data11 = pd.DataFrame(test_pre)
# writer = pd.ExcelWriter('D://毕业设计//Data//Forecasting//result//DEU.xlsx')		# 写入Excel文件
data11.to_csv("D://毕业设计//Data//Forecasting//result//result.csv")		# ‘page_1’是写入excel的sheet名
# writer.save()
# writer.close()
# np.savetxt("D://毕业设计//Data//Forecasting//result//result.csv", test_pre, delimiter=",", newline=",")

# for i in Top10:
#     print(i)
#     print('MAE:', metrics.mean_absolute_error(test_real1[:,i], test_pre[:, i]))
#     print('RMSE:', math.sqrt(mean_squared_error(test_real1[:,i], test_pre[:, i])))

MAE_list=[]
RMSE_list=[]
MAE=0
RMSE=0
for i in range(0,107):
    MAE=metrics.mean_absolute_error(test_real1[:, i], test_pre[:, i])
    RMSE=math.sqrt(mean_squared_error(test_real1[:, i], test_pre[:, i]))
    MAE_list.append(MAE)
    RMSE_list.append(RMSE)
    print('MAE:', metrics.mean_absolute_error(test_real1[:, i], test_pre[:, i]))
    print('RMSE:', math.sqrt(mean_squared_error(test_real1[:, i], test_pre[:, i])))


# print(test_real[:,103])
# plt.plot(test_real[:, 103], label='real data')
# plt.plot(test_pre[:, 103], label='pre data')
# plt.xlabel("Time steps")
# plt.ylabel("Normalized Price")
# plt.suptitle("prediction against truth")
# plt.legend()
# plt.show()

# Top10=np.array([103,13,34,81,38,29])
# plt.figure(1)
# for i in Top10:
#     # for j in range(0,6):
#         # plt.subplot(2, 3,j+1 )
#         plt.plot(test_real[:, i], label='real data')
#         plt.plot(test_pre[:, i], label='pre data')
#         plt.xlabel("Time steps")
#         plt.ylabel("Normalized Price")
#         plt.suptitle("prediction against truth")
#         plt.legend()
#         plt.show()


# plt.show()